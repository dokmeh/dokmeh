# Shuffle Letters

This is the library where [Shuffle Letters Effect](http://tutorialzine.com/2011/09/shuffle-letters-effect-jquery/) was rewritten in vanilla javascript.

## Installation

```bash
$ npm install yuheiy/shuffle-letters
```
